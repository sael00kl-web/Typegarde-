package com.typeguard.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "words", indices = [Index(value = ["text"], unique = true)])
data class Word(@PrimaryKey(autoGenerate = true) val id: Long = 0, val text: String)

@Dao
interface WordDao {
    @Query("SELECT * FROM words ORDER BY text")
    fun observe(): Flow<List<Word>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(w: Word)

    @Delete
    suspend fun delete(w: Word)
}

@Database(entities = [Word::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun wordDao(): WordDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "typeguard.db")
                .build().also { inst = it }
        }
    }
}

object WordCache {
    @Volatile private var words: List<String> = emptyList()
    fun set(list: List<String>) { words = list.map { it.trim().lowercase() }.filter { it.isNotEmpty() } }

    /** Returns text with banned words removed, or null if clean. */
    fun clean(text: String): String? {
        var out = text
        var hit = false
        for (w in words) {
            val re = Regex(Regex.escape(w), RegexOption.IGNORE_CASE)
            if (re.containsMatchIn(out)) { out = re.replace(out, ""); hit = true }
        }
        return if (hit) out else null
    }
}
