package com.typeguard.app

import android.app.Application
import com.typeguard.app.data.AppDb
import com.typeguard.app.data.WordCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class TypeGuardApp : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        val dao = AppDb.get(this).wordDao()
        scope.launch { dao.observe().collect { list -> WordCache.set(list.map { it.text }) } }
    }
}
