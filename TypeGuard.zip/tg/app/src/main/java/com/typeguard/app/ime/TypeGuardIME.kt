package com.typeguard.app.ime

import android.inputmethodservice.InputMethodService
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import com.typeguard.app.data.WordCache

class TypeGuardIME : InputMethodService() {
    private val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rows.forEach { r ->
            val row = LinearLayout(this)
            r.forEach { ch -> row.addView(key(ch.toString()) { type(ch.toString()) }, lp()) }
            root.addView(row)
        }
        val bottom = LinearLayout(this)
        bottom.addView(key("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) }, lp())
        bottom.addView(key("space") { type(" ") }, LinearLayout.LayoutParams(0, -2, 4f))
        bottom.addView(key("⏎") { currentInputConnection?.performEditorAction(currentInputEditorInfo.imeOptions and 0xff) }, lp())
        root.addView(bottom)
        return root
    }

    private fun lp() = LinearLayout.LayoutParams(0, -2, 1f)

    private fun key(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun type(s: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(s, 1)
        val before = ic.getTextBeforeCursor(200, 0)?.toString() ?: return
        val cleaned = WordCache.clean(before) ?: return
        ic.deleteSurroundingText(before.length, 0)
        ic.commitText(cleaned, 1)
    }

    @Suppress("unused") private val unused = GridLayout::class
}
