package com.typeguard.app.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.typeguard.app.data.AppDb
import com.typeguard.app.data.Word
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDb.get(this).wordDao()
        setContent {
            MaterialTheme {
                val words by dao.observe().collectAsState(initial = emptyList())
                var input by remember { mutableStateOf("") }
                val scope = rememberCoroutineScope()
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("TypeGuard", style = MaterialTheme.typography.headlineMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(input, { input = it }, Modifier.weight(1f), label = { Text("کلمه ممنوع") })
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = {
                            val t = input.trim()
                            if (t.isNotEmpty()) scope.launch { dao.insert(Word(text = t)) }
                            input = ""
                        }) { Text("افزودن") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("دسترسی‌پذیری") }
                        OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }) { Text("کیبورد") }
                    }
                    LazyColumn(Modifier.weight(1f)) {
                        items(words, key = { it.id }) { w ->
                            ListItem(
                                headlineContent = { Text(w.text) },
                                trailingContent = { TextButton(onClick = { scope.launch { dao.delete(w) } }) { Text("حذف") } }
                            )
                        }
                    }
                }
            }
        }
    }
}
